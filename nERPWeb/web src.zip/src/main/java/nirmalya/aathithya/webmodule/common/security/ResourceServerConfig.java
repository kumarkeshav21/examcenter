package nirmalya.aathithya.webmodule.common.security;

//import org.springframework.context.annotation.Configuration;

//@Configuration
//@EnableResourceServer
//public class ResourceServerConfig extends ResourceServerConfigurerAdapter {
//
//	private static final String RESOURCE_ID = "resource_id";
//
//	@Override
//	public void configure(ResourceServerSecurityConfigurer resources) {
//		resources.resourceId(RESOURCE_ID).stateless(false);
//	}
//
//}
