package nirmalya.aathithya.webmodule.employee.model;

import java.io.IOException;

import com.fasterxml.jackson.databind.ObjectMapper;

public class ExtendExitManagementModel {
	
	private String empID;
	private String empName;
	private String designation;
	private String noticePeriod;
	private Double salary;
	private String resignDate;
	private String releaseDate;
	private Double bonus;
	private Double recovery;
	private String reason;
	private String empStatus;
	private String financeStatus;
	
	public ExtendExitManagementModel() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	
	public String getEmpID() {
		return empID;
	}



	public String getEmpName() {
		return empName;
	}



	public String getDesignation() {
		return designation;
	}



	public String getNoticePeriod() {
		return noticePeriod;
	}



	public Double getSalary() {
		return salary;
	}



	public String getResignDate() {
		return resignDate;
	}



	public String getReleaseDate() {
		return releaseDate;
	}



	public Double getBonus() {
		return bonus;
	}



	public Double getRecovery() {
		return recovery;
	}



	public String getReason() {
		return reason;
	}



	public String getEmpStatus() {
		return empStatus;
	}



	public String getFinanceStatus() {
		return financeStatus;
	}



	public void setEmpID(String empID) {
		this.empID = empID;
	}



	public void setEmpName(String empName) {
		this.empName = empName;
	}



	public void setDesignation(String designation) {
		this.designation = designation;
	}



	public void setNoticePeriod(String noticePeriod) {
		this.noticePeriod = noticePeriod;
	}



	public void setSalary(Double salary) {
		this.salary = salary;
	}



	public void setResignDate(String resignDate) {
		this.resignDate = resignDate;
	}



	public void setReleaseDate(String releaseDate) {
		this.releaseDate = releaseDate;
	}



	public void setBonus(Double bonus) {
		this.bonus = bonus;
	}



	public void setRecovery(Double recovery) {
		this.recovery = recovery;
	}



	public void setReason(String reason) {
		this.reason = reason;
	}



	public void setEmpStatus(String empStatus) {
		this.empStatus = empStatus;
	}



	public void setFinanceStatus(String financeStatus) {
		this.financeStatus = financeStatus;
	}



	@Override
	public String toString() {
		ObjectMapper mapperObj = new ObjectMapper();
		String jsonStr;
		try {
			jsonStr = mapperObj.writeValueAsString(this);
		} catch (IOException ex) {

			jsonStr = ex.toString();
		}
		return jsonStr;
	}	
	

}
