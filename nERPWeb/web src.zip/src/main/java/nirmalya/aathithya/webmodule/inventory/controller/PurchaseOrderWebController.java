package nirmalya.aathithya.webmodule.inventory.controller;

import java.util.Arrays;
import java.util.List;
import javax.servlet.http.HttpSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import nirmalya.aathithya.webmodule.common.utils.DateFormatter;
import nirmalya.aathithya.webmodule.common.utils.DropDownModel;
import nirmalya.aathithya.webmodule.common.utils.EnvironmentVaribles;
import nirmalya.aathithya.webmodule.common.utils.JsonResponse;
import nirmalya.aathithya.webmodule.inventory.model.PurchaseOrderWebModel;
import nirmalya.aathithya.webmodule.master.model.LeaveApplyWebModel;

@Controller
@RequestMapping(value ="inventory/")
public class PurchaseOrderWebController {
	
	Logger logger = LoggerFactory.getLogger(PurchaseOrderWebController.class);
	@Autowired
	RestTemplate restTemplate;
	@Autowired
	EnvironmentVaribles environmentVaribles;
	
	@GetMapping("purchase-order")
	public String PurchaseOrder(Model model, HttpSession session) {
		logger.info("Method : leaveApply starts");

		try {
			DropDownModel[] vendor = restTemplate.getForObject(environmentVaribles.getInventoryUrl() + "getvendorlist",
					DropDownModel[].class);
			List<DropDownModel> vendorlist = Arrays.asList(vendor);
			model.addAttribute("vendorlist", vendorlist);
		} catch (RestClientException e) {
			e.printStackTrace();
		}
		
		logger.info("Method : leaveApply ends");
		return "inventory/purchase-order";
	}
	// view

	@SuppressWarnings("unchecked")
	@GetMapping("purchase-order-view")
	public @ResponseBody List<PurchaseOrderWebModel> viewPurchaseOrder(HttpSession session) {

		logger.info("Method : viewPurchaseOrder starts");

		JsonResponse<List<PurchaseOrderWebModel>> resp = new JsonResponse<List<PurchaseOrderWebModel>>();

		try {
			resp = restTemplate.getForObject(environmentVaribles.getInventoryUrl() + "viewpurchaseOrder", JsonResponse.class);
			
			} catch (RestClientException e) {
			e.printStackTrace();
		}
		ObjectMapper mapper = new ObjectMapper();

		List<PurchaseOrderWebModel> po = mapper.convertValue(resp.getBody(),
				new TypeReference<List<PurchaseOrderWebModel>>() {
				});
		String dateFormat = "";
		try {
			dateFormat = (String) session.getAttribute("DATEFORMAT");
		} catch (Exception e) {

		}
		
		for (PurchaseOrderWebModel a : po) {
			
			if (a.getDeliveryDate() != null && a.getDeliveryDate() != "") {
				a.setDeliveryDate(DateFormatter.dateFormat(a.getDeliveryDate(), dateFormat));
			}
			if (a.getCreatedDate() != null && a.getCreatedDate() != "") {
				a.setCreatedDate(DateFormatter.dateFormat(a.getCreatedDate(), dateFormat));
			}
		}

		System.out.println("po=="+po);
		logger.info("Method : viewPurchaseOrder ends");

		return po;
	}

	
	/*
	 * //Web Controller - Get Item List By AutoSearch
	 */

	@SuppressWarnings("unchecked")
	@PostMapping(value = { "purchase-order-itemlist-autosearch" })
	public @ResponseBody JsonResponse<PurchaseOrderWebModel> ItemAutoSearchList(Model model,
			@RequestBody String searchValue, BindingResult result) {

		logger.info("Method : ItemAutoSearchList starts");

		JsonResponse<PurchaseOrderWebModel> res = new JsonResponse<PurchaseOrderWebModel>();

		try {
			res = restTemplate.getForObject(
					environmentVaribles.getInventoryUrl() + "getitemListByAutoSearch?id=" + searchValue,
					JsonResponse.class);
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (res.getMessage() != null) {

			res.setCode(res.getMessage());
			res.setMessage("Unsuccess");
		} else {
			res.setMessage("success");
		}
		//System.out.println("res=="+res);
		logger.info("Method : ItemAutoSearchList ends");
		return res;

	}
	
	/*
	 * //Main save for purchase order
	 * 
	 */

	@SuppressWarnings({ "unchecked" })
	@PostMapping(value = "purchase-order-save")
	public @ResponseBody JsonResponse<Object> savePurchaseOrder(@RequestBody List<PurchaseOrderWebModel> purchaseOrder,
			HttpSession session) {
		logger.info("Method : savePurchaseOrder function starts");

		System.out.println(purchaseOrder);
		JsonResponse<Object> resp = new JsonResponse<Object>();
		String userId = "";
		String custId = "";
		String dateFormat = "";

		try {
			userId = (String) session.getAttribute("USER_ID");
			custId = (String) session.getAttribute("USER_ID");
			dateFormat = (String) session.getAttribute("DATEFORMAT");
		} catch (Exception e) {

		}
		for (PurchaseOrderWebModel m : purchaseOrder) {
			m.setCreatedBy(userId);
			m.setCustomerID(custId);
			
			if (m.getDeliveryDate() != null && m.getDeliveryDate() != "") {
				m.setDeliveryDate(DateFormatter.dateFormat(m.getDeliveryDate(), dateFormat));
			}

		}
		try {

			resp = restTemplate.postForObject(environmentVaribles.getInventoryUrl() + "savepurchaseorder", purchaseOrder,
					JsonResponse.class);

		} catch (RestClientException e) {
			e.printStackTrace();
		}

		String message = resp.getMessage();

		if (message != null && message != "") {

		} else {
			resp.setMessage("Success");
		}
		System.out.println("WEBBB" + resp);
		logger.info("Method : savePurchaseOrder function Ends");

		return resp;
	}

	// delete leave details table

		@SuppressWarnings("unchecked")
		@GetMapping("purchase-order-delete")
		public @ResponseBody JsonResponse<PurchaseOrderWebModel> deletePurchaseOrder(@RequestParam String deleteId) {

			logger.info("Method : deletePurchaseOrder starts");
			//System.out.println(deleteId);
			JsonResponse<PurchaseOrderWebModel> response = new JsonResponse<PurchaseOrderWebModel>();

			try {
				response = restTemplate.getForObject(environmentVaribles.getInventoryUrl() + "deletepurchaseorder?id=" + deleteId,
						JsonResponse.class);

			} catch (RestClientException e) {
				e.printStackTrace();
			}

			if (response.getMessage() != null && response.getMessage() != "") {
				response.setCode(response.getMessage());
				response.setMessage("Unsuccess");

			} else {
				response.setMessage("Success");
			}
			System.out.println(response);
			logger.info("Method : deletePurchaseOrder ends");
			return response;
		}
		
	//   edit leave apply

		@SuppressWarnings("unchecked")
		@GetMapping("purchase-order-edit")
		public @ResponseBody List<PurchaseOrderWebModel> editPurchaseOrder(@RequestParam String id, HttpSession session) {

			logger.info("Method : editPurchaseOrder starts");

			JsonResponse<List<PurchaseOrderWebModel>> resp = new JsonResponse<List<PurchaseOrderWebModel>>();
			try {

				resp = restTemplate.getForObject(environmentVaribles.getInventoryUrl() + "editpurchaseorder?id=" + id, JsonResponse.class);
			} catch (RestClientException e) {
				e.printStackTrace();
			}
			ObjectMapper mapper = new ObjectMapper();

			List<PurchaseOrderWebModel> purchaseOrder = mapper.convertValue(resp.getBody(),
					new TypeReference<List<PurchaseOrderWebModel>>() {
					});

			String dateFormat = "";
			try {

				dateFormat = (String) session.getAttribute("DATEFORMAT");
			} catch (Exception e) {

			}
			int i = 0;
			for (PurchaseOrderWebModel a : purchaseOrder) {
				i = i + 1;
				a.setRowId(i);
				if (a.getDeliveryDate() != null && a.getDeliveryDate() != "") {
					a.setDeliveryDate(DateFormatter.dateFormat(a.getDeliveryDate(), dateFormat));
				}
			}
			
			resp.setBody(purchaseOrder);
			if (resp.getMessage() != null && resp.getMessage() != "") {
				resp.setCode(resp.getMessage());
				resp.setMessage("Unsuccess");

			} else {
				resp.setMessage("Success");
			}

			System.out.println(resp);
			logger.info("Method : editPurchaseOrder ends");

			return purchaseOrder;
		}

}
