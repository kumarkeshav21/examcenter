package nirmalya.aathithya.webmodule.common.utils;

public class Snippet {
	public static void main(String[] args) {
		 
	}
}

