package nirmalya.aathithya.webmodule.leave.model;

public class LeaveCountModel {

}
