package nirmalya.aathithya.webmodule.inventory.model;

import java.io.IOException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class SalesPOSModel {
		
		private String billNo;
		private String custMobile;
		private String custID;
		private String custName;
		private Double billAmount;
		private String itemId;
		private String itemName;
		private Double quantity;
		private Double price;
		private String createdBy;
		private Double totalBillAmount;
		private Integer rowId;
		private String paymentMethod;
		private Double paidAmount;
		private String transactionNo;
		private String referenceNo;
		
		public SalesPOSModel() {
			super();
			// TODO Auto-generated constructor stub
		}

		public Double getPaidAmount() {
			return paidAmount;
		}

		public String getTransactionNo() {
			return transactionNo;
		}

		public String getReferenceNo() {
			return referenceNo;
		}

		public void setPaidAmount(Double paidAmount) {
			this.paidAmount = paidAmount;
		}

		public void setTransactionNo(String transactionNo) {
			this.transactionNo = transactionNo;
		}

		public void setReferenceNo(String referenceNo) {
			this.referenceNo = referenceNo;
		}

		public String getPaymentMethod() {
			return paymentMethod;
		}

		public void setPaymentMethod(String paymentMethod) {
			this.paymentMethod = paymentMethod;
		}

		public Double getTotalBillAmount() {
			return totalBillAmount;
		}

		public Integer getRowId() {
			return rowId;
		}

		public void setTotalBillAmount(Double totalBillAmount) {
			this.totalBillAmount = totalBillAmount;
		}



		public void setRowId(Integer rowId) {
			this.rowId = rowId;
		}



		public String getBillNo() {
			return billNo;
		}



		public String getCustMobile() {
			return custMobile;
		}



		public String getCustID() {
			return custID;
		}



		public String getCustName() {
			return custName;
		}



		public Double getBillAmount() {
			return billAmount;
		}



		public String getItemId() {
			return itemId;
		}



		public String getItemName() {
			return itemName;
		}



		public Double getQuantity() {
			return quantity;
		}



		public Double getPrice() {
			return price;
		}



		public String getCreatedBy() {
			return createdBy;
		}



		public void setBillNo(String billNo) {
			this.billNo = billNo;
		}



		public void setCustMobile(String custMobile) {
			this.custMobile = custMobile;
		}



		public void setCustID(String custID) {
			this.custID = custID;
		}



		public void setCustName(String custName) {
			this.custName = custName;
		}



		public void setBillAmount(Double billAmount) {
			this.billAmount = billAmount;
		}



		public void setItemId(String itemId) {
			this.itemId = itemId;
		}



		public void setItemName(String itemName) {
			this.itemName = itemName;
		}



		public void setQuantity(Double quantity) {
			this.quantity = quantity;
		}



		public void setPrice(Double price) {
			this.price = price;
		}



		public void setCreatedBy(String createdBy) {
			this.createdBy = createdBy;
		}



		@Override
		public String toString() {
			ObjectMapper mapperObj = new ObjectMapper();
			String jsonStr;
			try {
				jsonStr = mapperObj.writeValueAsString(this);
			} catch (IOException ex) {

				jsonStr = ex.toString();
			}
			return jsonStr;
		}
}
