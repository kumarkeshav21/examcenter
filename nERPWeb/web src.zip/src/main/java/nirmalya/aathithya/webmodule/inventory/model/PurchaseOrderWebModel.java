package nirmalya.aathithya.webmodule.inventory.model;

import java.io.IOException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class PurchaseOrderWebModel {
	private String poID;
	private String customerID;
	private String customerName;
	private String vendorID;
	private String vendorName;
	private String itemId;
	private String itemName;
	private String deliveryDate;
	private Double quantity;
	private Double price;
	private String poStatus;
	private String poCompleteStatus;
	private String createdBy;
	private String createdDate;
	private Integer rowId;
	
	
	public PurchaseOrderWebModel() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public Integer getRowId() {
		return rowId;
	}


	public void setRowId(Integer rowId) {
		this.rowId = rowId;
	}


	public String getPoID() {
		return poID;
	}
	public String getCustomerID() {
		return customerID;
	}
	public String getCustomerName() {
		return customerName;
	}
	public String getVendorID() {
		return vendorID;
	}
	public String getVendorName() {
		return vendorName;
	}
	public String getItemId() {
		return itemId;
	}
	public String getItemName() {
		return itemName;
	}
	public String getDeliveryDate() {
		return deliveryDate;
	}
	public Double getQuantity() {
		return quantity;
	}
	public Double getPrice() {
		return price;
	}
	public String getPoStatus() {
		return poStatus;
	}
	public String getPoCompleteStatus() {
		return poCompleteStatus;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setPoID(String poID) {
		this.poID = poID;
	}
	public void setCustomerID(String customerID) {
		this.customerID = customerID;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public void setVendorID(String vendorID) {
		this.vendorID = vendorID;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	public void setItemId(String itemId) {
		this.itemId = itemId;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public void setDeliveryDate(String deliveryDate) {
		this.deliveryDate = deliveryDate;
	}
	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public void setPoStatus(String poStatus) {
		this.poStatus = poStatus;
	}
	public void setPoCompleteStatus(String poCompleteStatus) {
		this.poCompleteStatus = poCompleteStatus;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	
	@Override
	public String toString() {
		ObjectMapper mapperObj = new ObjectMapper();
		String jsonStr;
		try {
			jsonStr = mapperObj.writeValueAsString(this);
		} catch (IOException ex) {

			jsonStr = ex.toString();
		}
		return jsonStr;
	}
}
