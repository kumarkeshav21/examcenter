package nirmalya.aathithya.webmodule.employee.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import nirmalya.aathithya.webmodule.common.utils.DateFormatter;
import nirmalya.aathithya.webmodule.common.utils.DropDownModel;
import nirmalya.aathithya.webmodule.common.utils.EnvironmentVaribles;
import nirmalya.aathithya.webmodule.common.utils.FileUpload;
import nirmalya.aathithya.webmodule.common.utils.JsonResponse;
import nirmalya.aathithya.webmodule.employee.model.ReimbursementDocumentModel;
import nirmalya.aathithya.webmodule.employee.model.ReimbursementModel;

@Controller
@RequestMapping(value = { "employee/" })
public class ReimbursementController {

	Logger logger = LoggerFactory.getLogger(ReimbursementController.class);

	@Autowired
	RestTemplate restTemplate;

	@Autowired
	EnvironmentVaribles env;
	
	@Autowired
	FileUpload fileUpload;
	

	@GetMapping("/reimbursement")
	public String employee(Model model, HttpSession session) {
		logger.info("Method : reimbursement starts");
		
		try {
			DropDownModel[] dropDownModel = restTemplate.getForObject(env.getEmployeeUrl() + "get-reimbursement-type",
					DropDownModel[].class);
			List<DropDownModel> reimType = Arrays.asList(dropDownModel);
			model.addAttribute("reimType", reimType);
		} catch (RestClientException e) {
			e.printStackTrace();
		}

		try {
			DropDownModel[] dropDownModel = restTemplate.getForObject(env.getEmployeeUrl() + "get-policy-type",
					DropDownModel[].class);
			List<DropDownModel> policyType = Arrays.asList(dropDownModel);
			model.addAttribute("policyType", policyType);
		} catch (RestClientException e) {
			e.printStackTrace();
		}

		logger.info("Method : reimbursement ends");
		return "employee/reimbursement";
	}

	/*
	 * View Reimbursement
	 * 
	 */
	
	@SuppressWarnings("unchecked")
	@GetMapping("reimbursement-view-through-ajax")
	public @ResponseBody List<ReimbursementModel> viewReimbursement(Model model, HttpSession session) {
		logger.info("Method : viewReimbursement starts");

		JsonResponse<List<ReimbursementModel>> jsonResponse = new JsonResponse<List<ReimbursementModel>>();

		try {

			jsonResponse = restTemplate.getForObject(env.getEmployeeUrl() + "reimbursement-view", JsonResponse.class);

			ObjectMapper mapper = new ObjectMapper();

			List<ReimbursementModel> addreq = mapper.convertValue(jsonResponse.getBody(),
					new TypeReference<List<ReimbursementModel>>() {
					});

			String dateFormat = (String) (session).getAttribute("DATEFORMAT");

			for (ReimbursementModel m : addreq) {

				if (m.getFromDate() != null && m.getFromDate() != "") {
					m.setFromDate(DateFormatter.dateFormat(m.getFromDate(), dateFormat));
				}

				if (m.getToDate() != null && m.getToDate() != "") {
					m.setToDate(DateFormatter.dateFormat(m.getToDate(), dateFormat));
				}

				if (m.getCreatedOn() != null && m.getCreatedOn() != "") {
					m.setCreatedOn(DateFormatter.dateFormat(m.getCreatedOn(), dateFormat));
				}
			}

			jsonResponse.setBody(addreq);

		} catch (Exception e) {
			e.printStackTrace();
		}

		logger.info("Method ; viewReimbursement ends");
		System.out.println(jsonResponse);
		return jsonResponse.getBody();
	}

	/*
	 * Add Reimbursement
	 * 
	 */

	@SuppressWarnings("unchecked")

	@PostMapping("reimbursement-add-details")
	public @ResponseBody JsonResponse<Object> addReimbursement(@RequestBody ReimbursementModel reimbursementModel,
			HttpSession session) {
		logger.info("Method : addReimbursement starts");
		System.out.println("@@@ADDDDDD" + reimbursementModel);
		String dateFormat = "";
		String userId = "";

		try {
			userId = (String) session.getAttribute("USER_ID");
			dateFormat = (String) session.getAttribute("DATEFORMAT");
		} catch (Exception e) {
			e.printStackTrace();
		}

		reimbursementModel.setCreatedBy(userId);

		if (reimbursementModel.getFromDate() != null && reimbursementModel.getFromDate() != "") {
			reimbursementModel.setFromDate(DateFormatter.dateFormat(reimbursementModel.getFromDate(), dateFormat));
		}

		if (reimbursementModel.getToDate() != null && reimbursementModel.getToDate() != "") {
			reimbursementModel.setToDate(DateFormatter.dateFormat(reimbursementModel.getToDate(), dateFormat));
		}

		JsonResponse<Object> resp = new JsonResponse<Object>();

		try {
			resp = restTemplate.postForObject(env.getEmployeeUrl() + "add-reimbursement", reimbursementModel,
					JsonResponse.class);
		} catch (RestClientException e) {
			e.printStackTrace();
		}

		if (resp.getMessage() != "" && resp.getMessage() != null) {
			resp.setCode(resp.getMessage());
			resp.setMessage("Unsuccess");
		} else {
			resp.setMessage("Success");
		}

		logger.info("Method : addReimbursement ends");
		
		return resp;
	}

	/*
	 * for editing Reimbursement
	 * 
	 */

	@SuppressWarnings("unchecked")
	@GetMapping("reimbursement-edit-through-ajax")
	public @ResponseBody JsonResponse<ReimbursementModel> editReimbursement(@RequestParam String id,
			HttpSession session) {

		logger.info("Method : editReimbursement starts");

		JsonResponse<ReimbursementModel> jsonResponse = new JsonResponse<ReimbursementModel>();

		try {
			jsonResponse = restTemplate.getForObject(env.getEmployeeUrl() + "edit-rest-reimbursement?id=" + id,
					JsonResponse.class);

		} catch (RestClientException e) {
			e.printStackTrace();
		}

		ObjectMapper mapper = new ObjectMapper();

		ReimbursementModel reimModel = mapper.convertValue(jsonResponse.getBody(),
				new TypeReference<ReimbursementModel>() {
				});
		String dateFormat = "";
		try {
			dateFormat = (String) session.getAttribute("DATEFORMAT");
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (reimModel.getFromDate() != null && reimModel.getFromDate() != "") {
			reimModel.setFromDate(DateFormatter.dateFormat(reimModel.getFromDate(), dateFormat));
		}
		if (reimModel.getToDate() != null && reimModel.getToDate() != "") {
			reimModel.setToDate(DateFormatter.dateFormat(reimModel.getToDate(), dateFormat));
		}

		jsonResponse.setBody(reimModel);
		if (jsonResponse.getMessage() != null && jsonResponse.getMessage() != "") {
			jsonResponse.setCode(jsonResponse.getMessage());
			jsonResponse.setMessage("Unsuccess");

		} else {
			jsonResponse.setMessage("Success");
		}

		logger.info("Method : editReimbursement ends");
		System.out.println(jsonResponse);
		return jsonResponse;
	}

	/*
	 *
	 * Delete Reimbursement
	 *
	 */
	
	@SuppressWarnings("unchecked")
	@GetMapping("reimbursement-delete-details")
	public @ResponseBody JsonResponse<ReimbursementModel> deleteReimbursement(@RequestParam String id) {
		System.out.println(id);
		logger.info("Method : deleteReimbursement starts");

		JsonResponse<ReimbursementModel> jsonResponse = new JsonResponse<ReimbursementModel>();

		try {
			jsonResponse = restTemplate.getForObject(env.getEmployeeUrl() + "deleteReimbursement?id=" + id,
					JsonResponse.class);

		} catch (RestClientException e) {
			e.printStackTrace();
		}

		if (jsonResponse.getMessage() != null && jsonResponse.getMessage() != "") {
			jsonResponse.setCode(jsonResponse.getMessage());
			jsonResponse.setMessage("Unsuccess");

		} else {
			jsonResponse.setMessage("Success");
		}

		logger.info("Method : deleteReimbursement ends");
		return jsonResponse;
	}
	
	
	/*
	 * post Mapping for add reimbursement requisition details
	 * 
	 */
	
	@SuppressWarnings("unchecked")
	@PostMapping(value = "reimbursement-req-save-th-ajax")
	public @ResponseBody JsonResponse<Object> saveReimbursementReq(@RequestBody List<ReimbursementModel> reimbursementModel, HttpSession session,
			Model model) {
		logger.info("Method : saveReimbursementReq function starts");
		System.out.println(reimbursementModel);
		JsonResponse<Object> res = new JsonResponse<Object>();
		
		List<ReimbursementModel> reimReqList = new ArrayList<ReimbursementModel>();
		
		List<ReimbursementDocumentModel> docList = new ArrayList<ReimbursementDocumentModel>();
		
		String userId = "";
		String dateFormat = "";
		try {
			userId = (String) session.getAttribute("USER_ID");
			dateFormat = (String) session.getAttribute("DATEFORMAT");
		} catch (Exception e) {

		}
		for (ReimbursementModel m : reimbursementModel) {
			m.setCreatedBy(userId);
			m.setExpenseDate(DateFormatter.inputDateFormat(m.getExpenseDate(), dateFormat));

		}
		for (ReimbursementDocumentModel a : reimbursementModel.get(0).getDocumentList()) {
			if (a.getImageNameEdit() != null && a.getImageNameEdit() != "") {
				a.setFileName(a.getImageNameEdit());
			} else {
				if (a.getFileName() != null && a.getFileName() != "") {
					String delimiters = "\\.";
					String[] x = a.getFileName().split(delimiters);

					if (x[1].contentEquals("png") || x[1].contentEquals("jpg") || x[1].contentEquals("jpeg")) {

						for (String s1 : a.getDocumentFile()) {
							if (s1 != null)
								try {
									byte[] bytes = Base64.getDecoder().decode(s1);
									String imageName = fileUpload.saveAllImage(bytes);
									a.setFileName(imageName);
								} catch (Exception e) {
									e.printStackTrace();
								}
						}
					} else if (x[1].contentEquals("pdf")) {
						for (String s1 : a.getDocumentFile()) {
							try {
								byte[] bytes = Base64.getDecoder().decode(s1);
								String pdfName = fileUpload.saveAllPdf(bytes);
								a.setFileName(pdfName);
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
					} else if (x[1].contentEquals("docx")) {
						for (String s1 : a.getDocumentFile()) {
							try {
								byte[] bytes = Base64.getDecoder().decode(s1);
								String pdfName = fileUpload.saveAllDocx(bytes);
								a.setFileName(pdfName);
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
					} else if (x[1].contentEquals("doc")) {
						for (String s1 : a.getDocumentFile()) {
							try {
								byte[] bytes = Base64.getDecoder().decode(s1);
								String pdfName = fileUpload.saveAllDoc(bytes);
								a.setFileName(pdfName);
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
					} else if (x[1].contentEquals("xls")) {
						for (String s1 : a.getDocumentFile()) {
							try {
								byte[] bytes = Base64.getDecoder().decode(s1);
								String pdfName = fileUpload.saveAllXls(bytes);
								a.setFileName(pdfName);
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
					} else if (x[1].contentEquals("xlsx")) {
						for (String s1 : a.getDocumentFile()) {
							try {
								byte[] bytes = Base64.getDecoder().decode(s1);
								String pdfName = fileUpload.saveAllXlsx(bytes);
								a.setFileName(pdfName);
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
					}
				}
			}
		}
		try {
			res = restTemplate.postForObject(env.getEmployeeUrl() + "reimbursement-req-rest-add",
					reimbursementModel, JsonResponse.class);

		} catch (RestClientException e) {
			e.printStackTrace();
		}
		ObjectMapper mapper = new ObjectMapper();

		reimReqList = mapper.convertValue(res.getBody(), new TypeReference<List<ReimbursementModel>>() {
		});
		if (reimReqList != null) {

			for (ReimbursementModel a : reimReqList) {
				if (a.getExpenseDate() != null && a.getExpenseDate() != "") {
					a.setExpenseDate(DateFormatter.dateFormat(a.getExpenseDate(), dateFormat));
				}
			}
			docList = reimReqList.get(0).getDocumentList();
			for (ReimbursementDocumentModel m : docList) {
				if (m.getFileName() != null && m.getFileName() != "") {
					String[] extension = m.getFileName().split("\\.");
					if (extension.length == 2) {
						if (extension[1].equals("xls") || extension[1].equals("xlsx")) {

							String docPath = "<i class=\"fa fa-file-excel-o excel\" title= " + m.getFileName()
									+ "></i> ";

							m.setAction(docPath);
						}
						if (extension[1].equals("pdf")) {
							String docPath = " <i class=\"fa fa-file-pdf-o excel pdf\"   title=" + m.getFileName()
									+ " ;></i> ";

							m.setAction(docPath);
						}
						if (extension[1].equals("doc") || extension[1].equals("dox") || extension[1].equals("docx")) {
							String docPath = " <i class=\"fa fa-file-word-o \" aria-hidden=\"true\"  title="
									+ m.getFileName() + "></i> ";
							m.setAction(docPath);
						}
						if (extension[1].equals("png") || extension[1].equals("jpg") || extension[1].equals("jpeg")) {
							String docPath = " <i class=\"fa fa-picture-o \"\" aria-hidden=\"true\" title="
									+ m.getFileName() + "></i>  ";
							m.setAction(docPath);
						}
					} else {
						m.setAction("N/A");
					}
				} else {
					m.setAction("N/A");
				}
				m.setAction("<a href=\"/document/procurment/" + m.getFileName() + "\" target=\"_blank\" >"
						+ m.getAction() + "</a>");

			}
		}
		String message = res.getMessage();
		reimReqList.get(0).setDocumentList(docList);
		if (message != null && message != "") {

		} else {
			res.setMessage("Success");
		}
		res.setBody(reimReqList);
		
		logger.info("Method : saveReimbursementReq function Ends");
		return res;
	}
	
}