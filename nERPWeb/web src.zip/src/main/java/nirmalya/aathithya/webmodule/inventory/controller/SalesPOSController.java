package nirmalya.aathithya.webmodule.inventory.controller;

import java.util.Arrays;
import java.util.List;
import javax.servlet.http.HttpSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import nirmalya.aathithya.webmodule.common.utils.DropDownModel;
import nirmalya.aathithya.webmodule.common.utils.EnvironmentVaribles;
import nirmalya.aathithya.webmodule.common.utils.JsonResponse;
import nirmalya.aathithya.webmodule.inventory.model.SalesPOSModel;

@Controller
@RequestMapping(value ="inventory/")
public class SalesPOSController {
	Logger logger = LoggerFactory.getLogger(SalesPOSController.class);
	@Autowired
	RestTemplate restTemplate;
	@Autowired
	EnvironmentVaribles environmentVaribles;
	
	@GetMapping("sales-pos")
	public String salesPOS(Model model, HttpSession session) {
		logger.info("Method : salesPOS starts");
		
		try {
			DropDownModel[] paymentMode = restTemplate.getForObject(environmentVaribles.getInventoryUrl() + "getpaymentModelist",
					DropDownModel[].class);
			List<DropDownModel> paymentModelist = Arrays.asList(paymentMode);
			model.addAttribute("paymentModelist", paymentModelist);
		} catch (RestClientException e) {
			e.printStackTrace();
		}
		
		logger.info("Method : salesPOS ends");
		return "inventory/sales-pos";
	}
	
	
	// view

		@SuppressWarnings("unchecked")
		@GetMapping("sales-pos-view")
		public @ResponseBody List<SalesPOSModel> viewSalesPOS(HttpSession session) {

			logger.info("Method : viewSalesPOS starts");

			JsonResponse<List<SalesPOSModel>> resp = new JsonResponse<List<SalesPOSModel>>();

			try {
				resp = restTemplate.getForObject(environmentVaribles.getInventoryUrl() + "viewsalespos", JsonResponse.class);
				
				} catch (RestClientException e) {
				e.printStackTrace();
			}
			ObjectMapper mapper = new ObjectMapper();

			List<SalesPOSModel> pos = mapper.convertValue(resp.getBody(),
					new TypeReference<List<SalesPOSModel>>() {
					});
			
			//sSystem.out.println("pos=="+pos);
			logger.info("Method : viewSalesPOS ends");

			return pos;
		}
		
		
		/*
		 * //Web Controller - Get Item List By AutoSearch
		 */

		@SuppressWarnings("unchecked")
		@PostMapping(value = { "sales-pos-itemlist-autosearch" })
		public @ResponseBody JsonResponse<SalesPOSModel> ItemAutoSearchList(Model model,
				@RequestBody String searchValue, BindingResult result) {

			logger.info("Method : ItemAutoSearchList starts");

			JsonResponse<SalesPOSModel> res = new JsonResponse<SalesPOSModel>();

			try {
				res = restTemplate.getForObject(
						environmentVaribles.getInventoryUrl() + "getitemByAutoSearch?id=" + searchValue,
						JsonResponse.class);
			} catch (Exception e) {
				e.printStackTrace();
			}

			if (res.getMessage() != null) {

				res.setCode(res.getMessage());
				res.setMessage("Unsuccess");
			} else {
				res.setMessage("success");
			}
			//System.out.println("res=="+res);
			logger.info("Method : ItemAutoSearchList ends");
			return res;

		}
		
		/*
		 * //Main save for sales pos
		 * 
		 */

		@SuppressWarnings({ "unchecked" })
		@PostMapping(value = "sales-pos-save")
		public @ResponseBody JsonResponse<Object> saveSalesPOS(@RequestBody List<SalesPOSModel> pos,
				HttpSession session) {
			logger.info("Method : saveSalesPOS function starts");

			//System.out.println(pos);
			JsonResponse<Object> resp = new JsonResponse<Object>();
			
			String userId = "";
			try {
				userId = (String) session.getAttribute("USER_ID");

			} catch (Exception e) {

			}
			for (SalesPOSModel m : pos) {
				m.setCreatedBy(userId);

			}

			try {

				resp = restTemplate.postForObject(environmentVaribles.getInventoryUrl() + "savesalespos", pos,
						JsonResponse.class);

			} catch (RestClientException e) {
				e.printStackTrace();
			}

			String message = resp.getMessage();

			if (message != null && message != "") {

			} else {
				resp.setMessage("Success");
			}
			//System.out.println("WEBBB" + resp);
			logger.info("Method : saveSalesPOS function Ends");

			return resp;
		}
		
		
		// delete sales pos table

		@SuppressWarnings("unchecked")
		@GetMapping("sales-pos-delete")
		public @ResponseBody JsonResponse<SalesPOSModel> deleteSalesPOS(@RequestParam String deleteId) {

			logger.info("Method : deleteSalesPOS starts");
			// System.out.println(deleteId);
			JsonResponse<SalesPOSModel> response = new JsonResponse<SalesPOSModel>();

			try {
				response = restTemplate.getForObject(
						environmentVaribles.getInventoryUrl() + "deletesalespos?id=" + deleteId,
						JsonResponse.class);

			} catch (RestClientException e) {
				e.printStackTrace();
			}

			if (response.getMessage() != null && response.getMessage() != "") {
				response.setCode(response.getMessage());
				response.setMessage("Unsuccess");

			} else {
				response.setMessage("Success");
			}
			//System.out.println(response);
			logger.info("Method : deleteSalesPOS ends");
			return response;
		}
		
	//   edit sales pos

	@SuppressWarnings("unchecked")
	@GetMapping("sales-pos-edit")
	public @ResponseBody List<SalesPOSModel> editSalesPOS(@RequestParam String id, HttpSession session) {

		logger.info("Method : editSalesPOS starts");

		JsonResponse<List<SalesPOSModel>> resp = new JsonResponse<List<SalesPOSModel>>();
		try {

			resp = restTemplate.getForObject(environmentVaribles.getInventoryUrl() + "editsalespos?id=" + id,
					JsonResponse.class);
		} catch (RestClientException e) {
			e.printStackTrace();
		}
		ObjectMapper mapper = new ObjectMapper();

		List<SalesPOSModel> pos = mapper.convertValue(resp.getBody(),
				new TypeReference<List<SalesPOSModel>>() {
				});

		int i = 0;
		for (SalesPOSModel a : pos) {
			i = i + 1;
			a.setRowId(i);
			
		}

		resp.setBody(pos);
		if (resp.getMessage() != null && resp.getMessage() != "") {
			resp.setCode(resp.getMessage());
			resp.setMessage("Unsuccess");

		} else {
			resp.setMessage("Success");
		}

		//System.out.println(resp);
		logger.info("Method : editSalesPOS ends");

		return pos;
	}
	
	/*
	 * //Web Controller - Get Item List By AutoSearch
	 */

	@SuppressWarnings("unchecked")
	@PostMapping(value = { "sales-pos-mobile-autosearch" })
	public @ResponseBody JsonResponse<SalesPOSModel> mobileAutoSearchList(Model model,
			@RequestBody String searchValue, BindingResult result) {

		logger.info("Method : mobileAutoSearchList starts");
		//System.out.println("searchValue=="+searchValue);
		JsonResponse<SalesPOSModel> res = new JsonResponse<SalesPOSModel>();

		try {
			res = restTemplate.getForObject(
					environmentVaribles.getInventoryUrl() + "getmobileByAutoSearch?id=" + searchValue,
					JsonResponse.class);
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (res.getMessage() != null) {

			res.setCode(res.getMessage());
			res.setMessage("Unsuccess");
		} else {
			res.setMessage("success");
		}
		//System.out.println("res=="+res);
		logger.info("Method : mobileAutoSearchList ends");
		return res;

	}
	
	

}
