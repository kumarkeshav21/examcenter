package nirmalya.aathithya.webmodule.common.utils;


public class DynamicMenu {

	boolean hasAccess(String url){
		
		return true;
	} 
}
