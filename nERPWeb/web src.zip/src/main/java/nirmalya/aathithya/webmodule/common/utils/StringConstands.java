package nirmalya.aathithya.webmodule.common.utils;

public final class StringConstands {

	 private StringConstands() {
		    throw new IllegalStateException("Utility class");
		  }
	public static final String USERID = "USER_ID";
}
