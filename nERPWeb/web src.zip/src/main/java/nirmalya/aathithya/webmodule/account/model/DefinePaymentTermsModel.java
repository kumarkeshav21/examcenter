package nirmalya.aathithya.webmodule.account.model;

public class DefinePaymentTermsModel {

	private String termId;
	private String termsComment;
	private String createdBy;
	
	public String getTermId() {
		return termId;
	}
	public void setTermId(String termId) {
		this.termId = termId;
	}
	public String getTermsComment() {
		return termsComment;
	}
	public void setTermsComment(String termsComment) {
		this.termsComment = termsComment;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	
}
