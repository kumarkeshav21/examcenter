package nirmalya.aathithya.webmodule.common.utils;

import org.springframework.beans.factory.annotation.Autowired;

import nirmalya.aathithya.webmodule.common.utils.EnvironmentVaribles;

public class Constant {
	
	@Autowired
	static EnvironmentVaribles env;

	public static String host = "Smtp.gmail.com";
	public static String port = "587";
	public static String mailFrom = "sagaranchal4@gmail.com";
	public static String password = "kharasrota";
//	public static String mailFrom="sdebendumohapatra@odishamining.in";
//	public static String password="sRinu@2000#";

	/*
	 * public static String host="Smtp.gmail.com"; public static String port="587";
	 * public static String mailFrom="welcomesuprava878@gmail.com"; public static
	 * String password="niranjanswain@123";
	 */

}