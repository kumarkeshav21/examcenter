package nirmalya.aathithya.webmodule.employee.controller;

import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import nirmalya.aathithya.webmodule.common.utils.DropDownModel;
import nirmalya.aathithya.webmodule.common.utils.EnvironmentVaribles;
import nirmalya.aathithya.webmodule.common.utils.JsonResponse;
import nirmalya.aathithya.webmodule.employee.model.ExtendExitManagementModel;

@Controller
@RequestMapping(value = "employee/")
public class ExtendExitManagementController {
	
	Logger logger = LoggerFactory.getLogger(ExtendExitManagementController.class);

	@Autowired
	RestTemplate restClient;

	@Autowired
	EnvironmentVaribles env;
	  
	@GetMapping("exit") 
	public String addExitManagement(Model model, HttpSession session) {

		logger.info("Method : addExitManagement starts");
		try {
			DropDownModel[] name = restClient.getForObject(env.getEmployeeUrl() + "getNamelist",
					DropDownModel[].class);
			List<DropDownModel> namelist = Arrays.asList(name);
			model.addAttribute("namelist", namelist);
		} catch (RestClientException e) { e.printStackTrace(); }

		logger.info("Method : addExitManagement ends");

		return "employee/extend-exit-management";
	}
	
	 //dropdown for job through ajax
	  
		@SuppressWarnings("unchecked")

		@GetMapping(value = { "exit-joblist-ajax" })
		public @ResponseBody JsonResponse<Object> getJobList(@RequestParam String name) {
			logger.info("Method : getJobList starts");
			JsonResponse<Object> res = new JsonResponse<Object>();
			try {
				res = restClient.getForObject(env.getEmployeeUrl() + "rest-get-designationList?id=" + name,
						JsonResponse.class);
			} catch (Exception e) {
				e.printStackTrace();
			}
			if (res.getMessage() != null) {
				res.setCode(res.getMessage());
				res.setMessage("Unsuccess");
			} else {
				res.setMessage("success");
			}
			System.out.println(res);
			logger.info("Method : getJobList ends");
			return res;

		}
	  
	
	//view
	  
	@SuppressWarnings("unchecked")

	@GetMapping("exit-view-through-ajax")
	public @ResponseBody List<ExtendExitManagementModel> viewExitManagement() {

		logger.info("Method : viewExitManagement starts");

		JsonResponse<List<ExtendExitManagementModel>> resp = new JsonResponse<List<ExtendExitManagementModel>>();

		try {
			resp = restClient.getForObject(env.getEmployeeUrl() + "viewExitManagement", JsonResponse.class);
		} catch (RestClientException e) {
			e.printStackTrace();
		}

		System.out.println(resp);
		logger.info("Method : viewExitManagement ends");

		return resp.getBody();
	}
	
	
	 //add
	  
	@SuppressWarnings("unchecked")

	@PostMapping("exit-add-details")
	public @ResponseBody JsonResponse<Object> addExitManagement(@RequestBody ExtendExitManagementModel exitModel) {

		logger.info("Method : addExitManagement starts");

		JsonResponse<Object> resp = new JsonResponse<Object>();

		try {
			resp = restClient.postForObject(env.getEmployeeUrl() + "addExitdetails", exitModel, JsonResponse.class);
		} catch (RestClientException e) {
			e.printStackTrace();
		}

		if (resp.getMessage() != "" && resp.getMessage() != null) {
			resp.setCode(resp.getMessage());
			resp.setMessage("Unsuccess");
		} else {
			resp.setMessage("Success");
		}

		System.out.println(resp);
		logger.info("Method : addExitManagement ends");

		return resp;
	}
	

}
